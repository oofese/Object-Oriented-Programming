﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odev3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Nesne olusturma
        Buzdolabi b1 = new Buzdolabi("Beko", "Nofrost", "Gardrop Tipi Buzdolabı", 150, 'A');
        LedTv l1 = new LedTv("Samsung", "Curve", "dsfs",50, 720);
        Laptop lap1 = new Laptop("HP", "EC0007NT", "GTX1650-Amd Ryzen 5 3550H",5.6, 1920, 4095, 2048, 10000);
        CepTel c1 = new CepTel("Xiaomi", "MI6", "Facial Recognition Software", 2048, 8192, 6000);

        private void Form1_Load(object sender, EventArgs e)
        {

            //Load da Stokadetleri direkt ciksin
            label10.Text = Convert.ToString(l1.StokAdedi);
            label15.Text = Convert.ToString(b1.StokAdedi);
            label20.Text = Convert.ToString(lap1.StokAdedi);
            label27.Text = Convert.ToString(c1.StokAdedi);
            label28.Text = Convert.ToString("0 TL");
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }
        private void label26_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
                    
            int l1_stok, b1_stok, lap1_stok, c1_stok;

            l1_stok = l1.StokAdedi;
            b1_stok = b1.StokAdedi;
            lap1_stok = lap1.StokAdedi;
            c1_stok = c1.StokAdedi;

            listBox3.Items.Clear();
            Adet.Items.Clear();
            Urun.Items.Clear();

            l1.SecilenAdet = Convert.ToInt32(numericUpDown1.Value);  //numericupdown u secilen adete atama
            b1.SecilenAdet = Convert.ToInt32(numericUpDown2.Value);
            lap1.SecilenAdet = Convert.ToInt32(numericUpDown3.Value);
            c1.SecilenAdet = Convert.ToInt32(numericUpDown4.Value);

            int l1_kdvli, b1_kdvli, lap1_kdvli, c1_kdvli;

            l1_kdvli = l1.KdvUygula() * l1.SecilenAdet;    //Kdv li fiyatlar
            b1_kdvli = b1.KdvUygula() * b1.SecilenAdet;
            lap1_kdvli = lap1.KdvUygula() * lap1.SecilenAdet;
            c1_kdvli = c1.KdvUygula() * c1.SecilenAdet;

            int top_fiyat = l1_kdvli + b1_kdvli + lap1_kdvli + c1_kdvli; //Toplam fiyat

            Adet.Items.Add(""+l1.SecilenAdet);             //listbox a ekleme islemleri
            Adet.Items.Add(""+ b1.SecilenAdet);
            Adet.Items.Add(""+ lap1.SecilenAdet);
            Adet.Items.Add(""+ c1.SecilenAdet);

            Urun.Items.Add("Led Tv");
            Urun.Items.Add("Buzdolabı");
            Urun.Items.Add("Laptop");
            Urun.Items.Add("Telefon");

            listBox3.Items.Add(""+l1_kdvli);
            listBox3.Items.Add(""+b1_kdvli);
            listBox3.Items.Add(""+lap1_kdvli);
            listBox3.Items.Add(""+c1_kdvli);

            l1_stok = l1_stok - l1.SecilenAdet;             //Sepeti Temizleye tiklayinca  stok adeti eski haline donsun diye stok adetini baska
            b1_stok = b1_stok - b1.SecilenAdet;             //degiskende tutup onla islem yaptim .
            lap1_stok = lap1_stok - lap1.SecilenAdet;         
            c1_stok = c1_stok - c1.SecilenAdet;         

            label10.Text = Convert.ToString(l1_stok);            //Labellerde print
            label15.Text = Convert.ToString(b1_stok);
            label20.Text = Convert.ToString(lap1_stok);
            label27.Text = Convert.ToString(c1_stok);
            label28.Text = Convert.ToString(top_fiyat+" TL");

        }     
        private void label5_Click(object sender, EventArgs e)
        {
            
        }
        private void label13_Click(object sender, EventArgs e)
        {

        }
        public void Adet_SelectedIndexChanged(object sender, EventArgs e)
        {           

        }
        public void Urun_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void label28_Click(object sender, EventArgs e)
        {
            
        }

        public void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        public void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
        public void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {

        }
        public void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();         //listbox temizleme
            Urun.Items.Clear();
            Adet.Items.Clear();
            label28.Text=Convert.ToString("0 TL");

            label10.Text = Convert.ToString(l1.StokAdedi);       //Temizle yapinca ilk Stok adedine doner.
            label15.Text = Convert.ToString(b1.StokAdedi);
            label20.Text = Convert.ToString(lap1.StokAdedi);
            label27.Text = Convert.ToString(c1.StokAdedi);
        }

        public void label10_Click(object sender, EventArgs e)
        {
                     
            
        }
        private void label15_Click(object sender, EventArgs e)
        {
                     
        }
        private void label20_Click(object sender, EventArgs e)
        {
            
        }
        private void label27_Click(object sender, EventArgs e)
        {
            
        }
    }
    public class Urun
    {
        public string Ad, Marka, Model, Ozellik;
        public int HamFiyat, StokAdedi, SecilenAdet;
        static protected Random rastgele = new Random();

        public Urun(string Marka,string Model, string Ozelliik)
        {
            Ad = "Beko";
            StokAdedi = rastgele.Next(1, 100);
        }
    }
    class Buzdolabi : Urun
    {
        double IcHacim;
        char EnerjiSinifi; 
             
       public  Buzdolabi(string Marka, string Model, string Ozellik,double IcHacim,char EnerjiSinifi) : base(Marka,Model,Ozellik)
        {
            
            IcHacim = 150;
            EnerjiSinifi = 'A';                         
        }
        public int KdvUygula()
        {           
            HamFiyat = 3500;         
            return HamFiyat + (HamFiyat * 5 / 100);
        }
    }
    class LedTv : Urun
    {
        double EkranBoyutu;
        int EkranCozunurlugu;

        public LedTv(string Marka, string Model, string Ozellik,double EkranBoyutu,int EkranCozunurlugu) : base(Marka, Model, Ozellik)
        {
            EkranBoyutu = 50;
            EkranBoyutu = 720;
        }
        public int KdvUygula() 
        {       
            HamFiyat = 4000;
            return HamFiyat + (HamFiyat * 18 / 100);
        }
    }
    class CepTel : Urun
    {     
        int DahiliHafiza;
        int RamKapasitesi;
        int PilGucu;
       
        public CepTel(string Marka, string Model, string Ozellik,int DahiliHafiza, int RamKapasitesi, int PilGucu) : base(Marka, Model, Ozellik)
        {
            DahiliHafiza = 2048;
            RamKapasitesi = 8192;
            PilGucu = 6000;

        }
        public int KdvUygula()
        {         
            HamFiyat = 2500;
            return HamFiyat + (HamFiyat * 20 / 100);
        }
    }
    class Laptop : Urun
    {
        double EkranBoyutu;
        int EkranCozunurluk;
        int DahiliHafiza;
        int RamKapasitesi;
        int PilGucu;     
        public Laptop(string Marka, string Model, string Ozellik,double EkranBoyutu, int EkranCozunurluk, int DahiliHafiza, int RamKapasitesi, int PilGucu) : base(Marka, Model, Ozellik)
        {
            EkranBoyutu = 5.6;
            EkranCozunurluk = 1920;
            DahiliHafiza = 4096;
            RamKapasitesi = 2048;
            PilGucu = 10000;
        }
        public int KdvUygula()
        {
            
            HamFiyat = 6000;
            return HamFiyat +(HamFiyat * 15 / 100);
        }

    }
    public class Sepet
    {      
       public int[] SepeteUrunEkle(int[] dizi,Urun Buzdolabi,Urun LedTv,Urun Laptop,Urun CepTel)//Urun tipinde parametre olusturma
        {
            
/*                                                     //Hocam kdvli toplam fiyati button clickinin icinde yaptim.Burada tam olarak ne 
                                                      // yapacagimi anlamadim :)
            dizi[0] = l1_kdvli;
            dizi[1] = b1_kdvli;
            dizi[2] = lap1_kdvli;
            dizi[3] = c1_kdvli;
            dizi[4] = top_fiyat;
*/
            return dizi;
        }
    }
}
