﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1
**				ÖĞRENCİ ADI............:Ömer Faruk Susuz
**				ÖĞRENCİ NUMARASI.......:B181210379
**                         DERSİN ALINDIĞI GRUP...:2-B
****************************************************************************/
using System;
using System.IO;
using System.Text;

namespace ndp1
{
    class Test
    {
        public static void Main()
        {
            try
            {               
                using (StreamReader sr = new StreamReader("input.txt"))
                {

                    //Degisken tanimlamalari
                    string line;                  
                    string odev1_notu,odev2_notu,vize_notu,final_notu;
                    int satir_sayisi = 0;
                    int aa_sayisi = 0;
                    int ba_sayisi = 0;
                    int bb_sayisi = 0;
                    int cb_sayisi = 0;
                    int cc_sayisi = 0;
                    int dc_sayisi = 0;
                    int dd_sayisi = 0;
                    int fd_sayisi = 0;
                    int ff_sayisi = 0;
                   
                    while ((line = sr.ReadLine()) != null)
                    {
                        //Belli koordinattaki string degerleri substring fonksiyonuyla alma
                         satir_sayisi++;                      
                         odev1_notu = line.Substring(20, 3);
                         odev2_notu = line.Substring(23, 3);
                         vize_notu = line.Substring(26, 3);
                         final_notu = line.Substring(29, 3);
    
                        // Odev vize ve finalden ortalama not hesaplama ve parse metoduyla double a cast etme
                        double ort=double.Parse(odev1_notu) / 10 + double.Parse(odev2_notu) / 10 + (double.Parse(vize_notu) / 10) * 3 + (double.Parse(final_notu) / 10) * 5;
                       //Harf notu kontrolleri ve hangi harf notundan kac kisi aldigini bulma
                        if (ort > 90)
                        {
                            aa_sayisi++;
                        }
                        else if (ort < 90 && 85 <= ort)
                        {
                            ba_sayisi++;
                        }
                        else if (ort < 85 && ort > 80 )
                        {
                            bb_sayisi++;
                        }
                        else if (ort < 80 && ort >=75)
                        {
                            cb_sayisi++;
                        }
                        else if (ort < 75 && ort >= 65)
                        {
                            cc_sayisi++;
                        }
                        else if (ort < 65 && ort >= 58)
                        {
                            dc_sayisi++;
                        }
                        else if (ort < 58 && ort >= 50)
                        {
                            dd_sayisi++;
                        }
                        else if (ort < 50 && ort >= 40)
                        {
                            fd_sayisi++;
                        }
                        else if (ort < 40)
                        {
                            ff_sayisi++;
                        }            
                    }
                                 
                using (StreamWriter wr = new StreamWriter("output.txt")) { // Yazma metodlari
                        
                        //Dosya yazma islemleri Math round metodu virgulden sonra 2 basamak icin 

                        wr.WriteLine("AA alanlarin sayisi : " + aa_sayisi + " Yuzde : " + (Math.Round((aa_sayisi * 100.0) / satir_sayisi,2)));
                        wr.WriteLine("BA alanlarin sayisi : " + ba_sayisi + " Yuzde : " + (Math.Round((ba_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("BB alanlarin sayisi : " + bb_sayisi + " Yuzde : " + (Math.Round((bb_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("CB alanlarin sayisi : " + cb_sayisi + " Yuzde : " + (Math.Round((cb_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("CC alanlarin sayisi : " + cc_sayisi + " Yuzde : " + (Math.Round((cc_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("DC alanlarin sayisi : " + dc_sayisi + " Yuzde : " + (Math.Round((dc_sayisi * 100.0) / satir_sayisi, 2))); 
                        wr.WriteLine("DD alanlarin sayisi : " + dd_sayisi + " Yuzde : " + (Math.Round((dd_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("FD alanlarin sayisi : " + fd_sayisi + " Yuzde : " + (Math.Round((fd_sayisi * 100.0) / satir_sayisi, 2)));
                        wr.WriteLine("FF alanlarin sayisi : " + ff_sayisi + " Yuzde : " + (Math.Round((ff_sayisi * 100.0) / satir_sayisi, 2)));
                    }
                }
            }
            catch (Exception e)
            {   
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(e.Message);
            }
        }
    }
}
