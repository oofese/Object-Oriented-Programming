﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2019-2020 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:2
**				ÖĞRENCİ ADI............:ÖMER FARUK SUSUZ
**				ÖĞRENCİ NUMARASI.......:B181210379
**                         DERSİN ALINDIĞI GRUP...:2-B
****************************************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)     //ARKADAS Mİ BUTONU
        {         

            //ARKADAS Mİ BUTONUNA BASİNCA EKLENECEK LİSTBOXLAR

            ListBox listBox1 = new ListBox();
            listBox1.Location = new System.Drawing.Point(300, 40);
            
            listBox1.Size = new System.Drawing.Size(100, 200);       
            listBox1.BackColor = System.Drawing.Color.Pink;
            listBox1.ForeColor = System.Drawing.Color.Black;
            Controls.Add(listBox1);

            ListBox listBox2 = new ListBox();
            listBox2.Location = new System.Drawing.Point(600, 40);
            listBox2.Size = new System.Drawing.Size(100, 200);
            listBox2.BackColor = System.Drawing.Color.Pink;
            listBox2.ForeColor = System.Drawing.Color.Black;
            Controls.Add(listBox2);

            //ARKADAS Mİ BUTONUNA BASİNCA EKLENECEK TEXTBOXLAR

            TextBox textBox3 = new TextBox();
            textBox3.Location = new System.Drawing.Point(300, 270);
            textBox3.Size = new System.Drawing.Size(100, 22);
            textBox3.BackColor = System.Drawing.Color.Orange;
            textBox3.ForeColor = System.Drawing.Color.Black;
            Controls.Add(textBox3);

            TextBox textBox4 = new TextBox();
            textBox4.Location = new System.Drawing.Point(600, 270);
            textBox4.Size = new System.Drawing.Size(100, 22);
            textBox4.BackColor = System.Drawing.Color.Orange;
            textBox4.ForeColor = System.Drawing.Color.Black;
            Controls.Add(textBox4);

            //ARKADAS Mİ BUTONUNA BASİNCA EKLENECEK LABELLER

            Label label3 = new Label();
            label3.Location = new System.Drawing.Point(340, 20);
            label3.AutoSize = true;
            label3.Text = "X";
            Controls.Add(label3);

            Label label4 = new Label();
            label4.Location = new System.Drawing.Point(640, 20);
            label4.AutoSize = true;
            label4.Text = "Y";
            Controls.Add(label4);

            Label label5 = new Label();
            label5.Location = new System.Drawing.Point(210, 270);
            label5.AutoSize = true;
            label5.Text = "TOPLAMLAR";
            Controls.Add(label5);

            //TANİMLAMALAR
            int i, sayi_x,sayi_y;
            int sayac_x = 0, sayac_y = 0;

            sayi_x = Convert.ToInt32(textBox1.Text);

            //BÖLENLERİ BULMA
            for (i = 1; i < sayi_x; i++)
            {

                if (sayi_x % i == 0)
                {
                    listBox1.Items.Add("" + i);    //BÖLENLERİ LİSTBOX A YAZMA
                    sayac_x = sayac_x + i;          //BÖLENLERİN TOPLAMI
                }
            }      
          
            sayi_y = Convert.ToInt32(textBox2.Text);

            for (i = 1; i < sayi_y; i++)
            {

                if (sayi_y % i == 0)
                {
                    listBox2.Items.Add("" + i);    //BÖLENLERİ LİSTBOX A YAZMA
                    sayac_y = sayac_y + i;        //BÖLENLERİN TOPLAMI
                }
            }
                        textBox3.Text=Convert.ToString(sayac_x); 
                        textBox4.Text = Convert.ToString(sayac_y);                     
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();   //SON BUTONUNA BASİNCA 
        }
    }
}
