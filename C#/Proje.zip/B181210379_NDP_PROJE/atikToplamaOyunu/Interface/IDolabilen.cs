﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atikToplamaOyunu
{
    public interface IDolabilen
    {
        int Kapasite { get; }
        int DoluHacim { get; set; }
        int DolulukOrani { get; set; }
    }
}
