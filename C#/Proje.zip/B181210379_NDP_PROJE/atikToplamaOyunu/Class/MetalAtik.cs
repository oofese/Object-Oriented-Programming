﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atikToplamaOyunu.Class
{
    public class MetalAtik : IAtikKutusu
    {
        public int BosaltmaPuani => 800;

        public int Kapasite => 2300;

        public int DoluHacim { get; set; }

        public int DolulukOrani { get; set; }

        public bool Ekle(Atik atik)
        {
            if (atik.Hacim + DoluHacim <= Kapasite)
            {
                DoluHacim =DoluHacim + atik.Hacim;
                DolulukOrani = Convert.ToInt32(Convert.ToDouble(DoluHacim) / Convert.ToDouble(Kapasite) * 100);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Bosalt()
        {
            if (DolulukOrani >= 75)
            {
                DoluHacim = 0;
                DolulukOrani = 0;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
