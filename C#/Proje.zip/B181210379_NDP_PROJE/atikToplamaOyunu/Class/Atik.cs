﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atikToplamaOyunu
{
    public enum AtikTipi
    {
        Organik = 1,
        Cam = 2,
        Metal = 3,
        Kagit = 4
    }

    public class Atik : IAtik
    {
        private  int _hacim;
        private  Image _resim;
        private  string _isim;
        private  AtikTipi _tip;

        public Atik(
            int hacim,
            Image resim,
            string isim,
            AtikTipi tip
            
            )
        {
            _hacim = hacim;
            _resim = resim;
            _isim = isim;
            _tip = tip;
        }

        public int Hacim { get { return _hacim; } }

        public Image Image { get { return _resim; } }

        public string Isim { get { return _isim; } }

        public AtikTipi Tip { get { return _tip; } }

    }
}
