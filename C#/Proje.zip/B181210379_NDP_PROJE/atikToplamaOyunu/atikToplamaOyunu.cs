﻿using atikToplamaOyunu.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atikToplamaOyunu
{
    public partial class atikToplamaOyunu : Form
    {    
        //Nesneler

        private Atik _guncelAtik;
        private OrganikAtik _organikAtik;
        private MetalAtik _metalAtik;
        private CamAtik _camAtik;
        private KagitAtik _kagitAtik;
        private List <Atik> _Atiks;
        
        public atikToplamaOyunu()
        {
            InitializeComponent();
        }
        private void KalanSure(int ek)
        {
            int zaman = int.Parse(label_OyunSuresi.Text);
            int guncelZaman = zaman + ek;

            if (guncelZaman == 0)
            {
                timerGameTime.Enabled = false;

                picAtikImage.InitialImage = null;

                button_OrganikAtikEkle.Enabled = false;
                btnOrganikAtikBosalt.Enabled = false;

                btnkagitAtikEkle.Enabled = false;
                btnKagitAtikBosalt.Enabled = false;

                btnCamAtikEkle.Enabled = false;
                btnCamAtikBosalt.Enabled = false;

                btnMetalAtikEkle.Enabled = false;
                btnMetalAtikBosalt.Enabled = false;

                btnYeniOyun.Enabled = true;
            }
                
            label_OyunSuresi.Text = Convert.ToString(guncelZaman);
        }

        private void Rastgelelik()
        {
            Random rand = new Random();
            
            _guncelAtik = _Atiks[rand.Next(0, 7)];
            picAtikImage.Image = _guncelAtik.Image;
        }

        private void Ekle_Puan(int puan)
        {        
            lblPuan.Text = Convert.ToString(int.Parse(lblPuan.Text) + puan);
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        

            private void btnYeniOyun_Click(object sender, EventArgs e)
        {
            _organikAtik = new OrganikAtik();
            _kagitAtik = new KagitAtik();
            _camAtik = new CamAtik();
            _metalAtik = new MetalAtik();
           

            button_OrganikAtikEkle.Enabled = true;
            btnOrganikAtikBosalt.Enabled = true;
            prgOrganikAtik.Value = 0;
            listOrg.Items.Clear();

            btnkagitAtikEkle.Enabled = true;
            btnKagitAtikBosalt.Enabled = true;
            prgKagitAtik.Value = 0;
            listKagit.Items.Clear();

            btnCamAtikEkle.Enabled = true;
            btnCamAtikBosalt.Enabled = true;
            prgCamAtik.Value = 0;
            listCam.Items.Clear();

            btnMetalAtikEkle.Enabled = true;
            btnMetalAtikBosalt.Enabled = true;
            prgMetalAtik.Value = 0;
            listMetal.Items.Clear();

            lblPuan.Text = "0";
            label_OyunSuresi.Text = "60";

            btnYeniOyun.Enabled = false;
            

            _Atiks = new List<Atik>();
            _Atiks.Add(new Atik(120, Image.FromFile("salatalik.jpg"), "Salatalik", AtikTipi.Organik));
            _Atiks.Add(new Atik(150, Image.FromFile("domates.jpg"), "Domates", AtikTipi.Organik));
            _Atiks.Add(new Atik(250, Image.FromFile("gazete.jpg"), "Gazete", AtikTipi.Kagit));
            _Atiks.Add(new Atik(200, Image.FromFile("dergi.jpg"), "Dergi", AtikTipi.Kagit));
            _Atiks.Add(new Atik(600, Image.FromFile("camsise.jpg"), "Cam Sise", AtikTipi.Cam));
            _Atiks.Add(new Atik(250, Image.FromFile("bardak.jpg"), "Bardak", AtikTipi.Cam));   
            _Atiks.Add(new Atik(350, Image.FromFile("kolakutusu.jpg"), "Kola Kutusu", AtikTipi.Metal));
            _Atiks.Add(new Atik(350, Image.FromFile("salcakutusu.jpg"), "Salca Kutusu", AtikTipi.Metal));

            Rastgelelik();

            timerGameTime.Enabled = true;
        }

        private void timerOyunZamani_Tick(object sender, EventArgs e)
        {
            KalanSure(-1);
        }

        private void button_OrganikAtikEkle_Click(object sender, EventArgs e)
        {
            if (_guncelAtik.Tip == AtikTipi.Organik)
            {
                if (_organikAtik.Ekle(_guncelAtik))
                {
                    listOrg.Items.Add(_guncelAtik.Isim + " (" + Convert.ToString(_guncelAtik.Hacim) + ")");
                    Ekle_Puan(_guncelAtik.Hacim);
                    prgOrganikAtik.Value = _organikAtik.DolulukOrani;
                    Rastgelelik();
                }
            }
        }
        private void btnkagitAtikEkle_Click(object sender, EventArgs e)
        {
            if (_guncelAtik.Tip == AtikTipi.Kagit)
            {
                if (_kagitAtik.Ekle(_guncelAtik))
                {
                    listKagit.Items.Add(_guncelAtik.Isim + " (" + Convert.ToString(_guncelAtik.Hacim) + ")");
                    Ekle_Puan(_guncelAtik.Hacim);
                    prgKagitAtik.Value = _kagitAtik.DolulukOrani;
                    Rastgelelik();
                }
            }
        }
        private void btnCamAtikEkle_Click(object sender, EventArgs e)
        {
            if (_guncelAtik.Tip == AtikTipi.Cam)
            {
                if (_camAtik.Ekle(_guncelAtik))
                {
                    listCam.Items.Add(_guncelAtik.Isim + " (" + Convert.ToString(_guncelAtik.Hacim) + ")");
                    Ekle_Puan(_guncelAtik.Hacim);
                    prgCamAtik.Value = _camAtik.DolulukOrani;
                    Rastgelelik();
                }
            }
        }
        private void btnMetalAtikEkle_Click(object sender, EventArgs e)
        {
            if (_guncelAtik.Tip == AtikTipi.Metal)
            {
                if (_metalAtik.Ekle(_guncelAtik))
                {
                    listMetal.Items.Add(_guncelAtik.Isim + " (" + Convert.ToString(_guncelAtik.Hacim) + ")");
                    Ekle_Puan(_guncelAtik.Hacim);
                    prgMetalAtik.Value = _metalAtik.DolulukOrani;
                    Rastgelelik();
                }
            }
        }

        private void btnOrganikAtikBosalt_Click(object sender, EventArgs e)
        {
            if (_organikAtik.Bosalt())
            {
                listOrg.Items.Clear();
                prgOrganikAtik.Value = 0;
                Ekle_Puan(_organikAtik.BosaltmaPuani);
                KalanSure(3);
            }
        }

        private void btnKagitAtikBosalt_Click(object sender, EventArgs e)
        {
            if (_kagitAtik.Bosalt())
            {
                listKagit.Items.Clear();
                prgKagitAtik.Value = 0;
                Ekle_Puan(_kagitAtik.BosaltmaPuani);
                KalanSure(3);
            }
        }

        private void btnCamAtikBosalt_Click(object sender, EventArgs e)
        {
            if (_camAtik.Bosalt())
            {
                listCam.Items.Clear();
                prgCamAtik.Value = 0;
                Ekle_Puan(_camAtik.BosaltmaPuani);
                KalanSure(3);
            }
        }

        private void btnMetalAtikBosalt_Click(object sender, EventArgs e)
        {
            if (_metalAtik.Bosalt())
            {
                listMetal.Items.Clear();
                prgMetalAtik.Value = 0;
                Ekle_Puan(_metalAtik.BosaltmaPuani);
                KalanSure(3);
            }
        }

        private void picAtikImage_Click(object sender, EventArgs e)
        {

        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblPuan_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void prgOrganikAtik_Click(object sender, EventArgs e)
        {

        }

        private void lstOrganikAtiklar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
