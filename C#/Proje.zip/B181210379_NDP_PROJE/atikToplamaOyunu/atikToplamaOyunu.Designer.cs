﻿namespace atikToplamaOyunu
{
    partial class atikToplamaOyunu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.picAtikImage = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCikis = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lblPuan = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label_OyunSuresi = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnYeniOyun = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.listKagit = new System.Windows.Forms.ListBox();
            this.btnkagitAtikEkle = new System.Windows.Forms.Button();
            this.prgKagitAtik = new System.Windows.Forms.ProgressBar();
            this.btnKagitAtikBosalt = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listMetal = new System.Windows.Forms.ListBox();
            this.btnMetalAtikEkle = new System.Windows.Forms.Button();
            this.prgMetalAtik = new System.Windows.Forms.ProgressBar();
            this.btnMetalAtikBosalt = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.listOrg = new System.Windows.Forms.ListBox();
            this.button_OrganikAtikEkle = new System.Windows.Forms.Button();
            this.prgOrganikAtik = new System.Windows.Forms.ProgressBar();
            this.btnOrganikAtikBosalt = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listCam = new System.Windows.Forms.ListBox();
            this.btnCamAtikEkle = new System.Windows.Forms.Button();
            this.prgCamAtik = new System.Windows.Forms.ProgressBar();
            this.btnCamAtikBosalt = new System.Windows.Forms.Button();
            this.timerGameTime = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAtikImage)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.picAtikImage);
            this.panel1.Location = new System.Drawing.Point(16, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 246);
            this.panel1.TabIndex = 0;
            // 
            // picAtikImage
            // 
            this.picAtikImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(212)))), ((int)(((byte)(210)))));
            this.picAtikImage.Location = new System.Drawing.Point(16, 15);
            this.picAtikImage.Margin = new System.Windows.Forms.Padding(4);
            this.picAtikImage.Name = "picAtikImage";
            this.picAtikImage.Size = new System.Drawing.Size(233, 215);
            this.picAtikImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAtikImage.TabIndex = 0;
            this.picAtikImage.TabStop = false;
            this.picAtikImage.Click += new System.EventHandler(this.picAtikImage_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel2.Controls.Add(this.btnCikis);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.btnYeniOyun);
            this.panel2.Location = new System.Drawing.Point(16, 267);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(267, 437);
            this.panel2.TabIndex = 1;
            // 
            // btnCikis
            // 
            this.btnCikis.BackColor = System.Drawing.Color.Red;
            this.btnCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.White;
            this.btnCikis.Location = new System.Drawing.Point(16, 385);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(4);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(233, 48);
            this.btnCikis.TabIndex = 11;
            this.btnCikis.Text = "ÇIKIŞ";
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(253)))), ((int)(((byte)(248)))));
            this.panel11.Controls.Add(this.lblPuan);
            this.panel11.Location = new System.Drawing.Point(16, 246);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(233, 71);
            this.panel11.TabIndex = 10;
            // 
            // lblPuan
            // 
            this.lblPuan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(253)))), ((int)(((byte)(248)))));
            this.lblPuan.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblPuan.Enabled = false;
            this.lblPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold);
            this.lblPuan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(208)))), ((int)(((byte)(197)))));
            this.lblPuan.Location = new System.Drawing.Point(20, 16);
            this.lblPuan.Margin = new System.Windows.Forms.Padding(4);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(192, 42);
            this.lblPuan.TabIndex = 8;
            this.lblPuan.Text = "0";
            this.lblPuan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lblPuan.TextChanged += new System.EventHandler(this.lblPuan_TextChanged);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(253)))), ((int)(((byte)(248)))));
            this.panel10.Controls.Add(this.label_OyunSuresi);
            this.panel10.Location = new System.Drawing.Point(16, 124);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(233, 71);
            this.panel10.TabIndex = 8;
            // 
            // label_OyunSuresi
            // 
            this.label_OyunSuresi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(253)))), ((int)(((byte)(248)))));
            this.label_OyunSuresi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.label_OyunSuresi.Enabled = false;
            this.label_OyunSuresi.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold);
            this.label_OyunSuresi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(208)))), ((int)(((byte)(197)))));
            this.label_OyunSuresi.Location = new System.Drawing.Point(20, 16);
            this.label_OyunSuresi.Margin = new System.Windows.Forms.Padding(4);
            this.label_OyunSuresi.Name = "label_OyunSuresi";
            this.label_OyunSuresi.Size = new System.Drawing.Size(192, 42);
            this.label_OyunSuresi.TabIndex = 9;
            this.label_OyunSuresi.Text = "60";
            this.label_OyunSuresi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel12.Controls.Add(this.label3);
            this.panel12.Location = new System.Drawing.Point(16, 203);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(233, 44);
            this.panel12.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(79, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "PUAN";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel9.Controls.Add(this.label2);
            this.panel9.Location = new System.Drawing.Point(16, 81);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(233, 44);
            this.panel9.TabIndex = 7;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(77, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "SÜRE";
            // 
            // btnYeniOyun
            // 
            this.btnYeniOyun.BackColor = System.Drawing.Color.Purple;
            this.btnYeniOyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYeniOyun.ForeColor = System.Drawing.Color.White;
            this.btnYeniOyun.Location = new System.Drawing.Point(16, 12);
            this.btnYeniOyun.Margin = new System.Windows.Forms.Padding(4);
            this.btnYeniOyun.Name = "btnYeniOyun";
            this.btnYeniOyun.Size = new System.Drawing.Size(233, 62);
            this.btnYeniOyun.TabIndex = 0;
            this.btnYeniOyun.Text = "YENİ OYUN";
            this.btnYeniOyun.UseVisualStyleBackColor = false;
            this.btnYeniOyun.Click += new System.EventHandler(this.btnYeniOyun_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(291, 15);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(632, 43);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(227, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "ATIK KUTULARI";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel5.Controls.Add(this.listKagit);
            this.panel5.Controls.Add(this.btnkagitAtikEkle);
            this.panel5.Controls.Add(this.prgKagitAtik);
            this.panel5.Controls.Add(this.btnKagitAtikBosalt);
            this.panel5.Location = new System.Drawing.Point(604, 65);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(319, 298);
            this.panel5.TabIndex = 4;
            // 
            // listKagit
            // 
            this.listKagit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.listKagit.FormattingEnabled = true;
            this.listKagit.ItemHeight = 16;
            this.listKagit.Location = new System.Drawing.Point(13, 49);
            this.listKagit.Margin = new System.Windows.Forms.Padding(4);
            this.listKagit.Name = "listKagit";
            this.listKagit.Size = new System.Drawing.Size(285, 164);
            this.listKagit.TabIndex = 5;
            // 
            // btnkagitAtikEkle
            // 
            this.btnkagitAtikEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnkagitAtikEkle.Enabled = false;
            this.btnkagitAtikEkle.FlatAppearance.BorderSize = 0;
            this.btnkagitAtikEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnkagitAtikEkle.Location = new System.Drawing.Point(13, 11);
            this.btnkagitAtikEkle.Margin = new System.Windows.Forms.Padding(4);
            this.btnkagitAtikEkle.Name = "btnkagitAtikEkle";
            this.btnkagitAtikEkle.Size = new System.Drawing.Size(287, 31);
            this.btnkagitAtikEkle.TabIndex = 5;
            this.btnkagitAtikEkle.Text = "KÂĞIT";
            this.btnkagitAtikEkle.UseVisualStyleBackColor = false;
            this.btnkagitAtikEkle.Click += new System.EventHandler(this.btnkagitAtikEkle_Click);
            // 
            // prgKagitAtik
            // 
            this.prgKagitAtik.Location = new System.Drawing.Point(13, 225);
            this.prgKagitAtik.Margin = new System.Windows.Forms.Padding(4);
            this.prgKagitAtik.Name = "prgKagitAtik";
            this.prgKagitAtik.Size = new System.Drawing.Size(287, 25);
            this.prgKagitAtik.TabIndex = 6;
            // 
            // btnKagitAtikBosalt
            // 
            this.btnKagitAtikBosalt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnKagitAtikBosalt.Enabled = false;
            this.btnKagitAtikBosalt.FlatAppearance.BorderSize = 0;
            this.btnKagitAtikBosalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnKagitAtikBosalt.Location = new System.Drawing.Point(13, 257);
            this.btnKagitAtikBosalt.Margin = new System.Windows.Forms.Padding(4);
            this.btnKagitAtikBosalt.Name = "btnKagitAtikBosalt";
            this.btnKagitAtikBosalt.Size = new System.Drawing.Size(287, 37);
            this.btnKagitAtikBosalt.TabIndex = 5;
            this.btnKagitAtikBosalt.Text = "BOŞALT";
            this.btnKagitAtikBosalt.UseVisualStyleBackColor = false;
            this.btnKagitAtikBosalt.Click += new System.EventHandler(this.btnKagitAtikBosalt_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel6.Controls.Add(this.listMetal);
            this.panel6.Controls.Add(this.btnMetalAtikEkle);
            this.panel6.Controls.Add(this.prgMetalAtik);
            this.panel6.Controls.Add(this.btnMetalAtikBosalt);
            this.panel6.Location = new System.Drawing.Point(604, 370);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(319, 334);
            this.panel6.TabIndex = 5;
            // 
            // listMetal
            // 
            this.listMetal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.listMetal.FormattingEnabled = true;
            this.listMetal.ItemHeight = 16;
            this.listMetal.Location = new System.Drawing.Point(13, 49);
            this.listMetal.Margin = new System.Windows.Forms.Padding(4);
            this.listMetal.Name = "listMetal";
            this.listMetal.Size = new System.Drawing.Size(285, 196);
            this.listMetal.TabIndex = 8;
            // 
            // btnMetalAtikEkle
            // 
            this.btnMetalAtikEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnMetalAtikEkle.Enabled = false;
            this.btnMetalAtikEkle.FlatAppearance.BorderSize = 0;
            this.btnMetalAtikEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnMetalAtikEkle.Location = new System.Drawing.Point(13, 11);
            this.btnMetalAtikEkle.Margin = new System.Windows.Forms.Padding(4);
            this.btnMetalAtikEkle.Name = "btnMetalAtikEkle";
            this.btnMetalAtikEkle.Size = new System.Drawing.Size(287, 31);
            this.btnMetalAtikEkle.TabIndex = 5;
            this.btnMetalAtikEkle.Text = "METAL";
            this.btnMetalAtikEkle.UseVisualStyleBackColor = false;
            this.btnMetalAtikEkle.Click += new System.EventHandler(this.btnMetalAtikEkle_Click);
            // 
            // prgMetalAtik
            // 
            this.prgMetalAtik.Location = new System.Drawing.Point(13, 256);
            this.prgMetalAtik.Margin = new System.Windows.Forms.Padding(4);
            this.prgMetalAtik.Name = "prgMetalAtik";
            this.prgMetalAtik.Size = new System.Drawing.Size(287, 25);
            this.prgMetalAtik.TabIndex = 6;
            // 
            // btnMetalAtikBosalt
            // 
            this.btnMetalAtikBosalt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnMetalAtikBosalt.Enabled = false;
            this.btnMetalAtikBosalt.FlatAppearance.BorderSize = 0;
            this.btnMetalAtikBosalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnMetalAtikBosalt.Location = new System.Drawing.Point(13, 288);
            this.btnMetalAtikBosalt.Margin = new System.Windows.Forms.Padding(4);
            this.btnMetalAtikBosalt.Name = "btnMetalAtikBosalt";
            this.btnMetalAtikBosalt.Size = new System.Drawing.Size(287, 37);
            this.btnMetalAtikBosalt.TabIndex = 5;
            this.btnMetalAtikBosalt.Text = "BOŞALT";
            this.btnMetalAtikBosalt.UseVisualStyleBackColor = false;
            this.btnMetalAtikBosalt.Click += new System.EventHandler(this.btnMetalAtikBosalt_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel7.Controls.Add(this.listOrg);
            this.panel7.Controls.Add(this.button_OrganikAtikEkle);
            this.panel7.Controls.Add(this.prgOrganikAtik);
            this.panel7.Controls.Add(this.btnOrganikAtikBosalt);
            this.panel7.Location = new System.Drawing.Point(291, 65);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(305, 298);
            this.panel7.TabIndex = 6;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // listOrg
            // 
            this.listOrg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.listOrg.FormattingEnabled = true;
            this.listOrg.ItemHeight = 16;
            this.listOrg.Location = new System.Drawing.Point(17, 49);
            this.listOrg.Margin = new System.Windows.Forms.Padding(4);
            this.listOrg.Name = "listOrg";
            this.listOrg.Size = new System.Drawing.Size(264, 164);
            this.listOrg.TabIndex = 0;
            this.listOrg.SelectedIndexChanged += new System.EventHandler(this.lstOrganikAtiklar_SelectedIndexChanged);
            // 
            // button_OrganikAtikEkle
            // 
            this.button_OrganikAtikEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.button_OrganikAtikEkle.Enabled = false;
            this.button_OrganikAtikEkle.FlatAppearance.BorderSize = 0;
            this.button_OrganikAtikEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.button_OrganikAtikEkle.Location = new System.Drawing.Point(17, 10);
            this.button_OrganikAtikEkle.Margin = new System.Windows.Forms.Padding(4);
            this.button_OrganikAtikEkle.Name = "button_OrganikAtikEkle";
            this.button_OrganikAtikEkle.Size = new System.Drawing.Size(265, 31);
            this.button_OrganikAtikEkle.TabIndex = 4;
            this.button_OrganikAtikEkle.Text = "ORGANİK ATIK";
            this.button_OrganikAtikEkle.UseVisualStyleBackColor = false;
            this.button_OrganikAtikEkle.Click += new System.EventHandler(this.button_OrganikAtikEkle_Click);
            // 
            // prgOrganikAtik
            // 
            this.prgOrganikAtik.Location = new System.Drawing.Point(17, 225);
            this.prgOrganikAtik.Margin = new System.Windows.Forms.Padding(4);
            this.prgOrganikAtik.Name = "prgOrganikAtik";
            this.prgOrganikAtik.Size = new System.Drawing.Size(265, 25);
            this.prgOrganikAtik.TabIndex = 2;
            this.prgOrganikAtik.Click += new System.EventHandler(this.prgOrganikAtik_Click);
            // 
            // btnOrganikAtikBosalt
            // 
            this.btnOrganikAtikBosalt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnOrganikAtikBosalt.Enabled = false;
            this.btnOrganikAtikBosalt.FlatAppearance.BorderSize = 0;
            this.btnOrganikAtikBosalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnOrganikAtikBosalt.Location = new System.Drawing.Point(17, 257);
            this.btnOrganikAtikBosalt.Margin = new System.Windows.Forms.Padding(4);
            this.btnOrganikAtikBosalt.Name = "btnOrganikAtikBosalt";
            this.btnOrganikAtikBosalt.Size = new System.Drawing.Size(265, 37);
            this.btnOrganikAtikBosalt.TabIndex = 1;
            this.btnOrganikAtikBosalt.Text = "BOŞALT";
            this.btnOrganikAtikBosalt.UseVisualStyleBackColor = false;
            this.btnOrganikAtikBosalt.Click += new System.EventHandler(this.btnOrganikAtikBosalt_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel4.Controls.Add(this.listCam);
            this.panel4.Controls.Add(this.btnCamAtikEkle);
            this.panel4.Controls.Add(this.prgCamAtik);
            this.panel4.Controls.Add(this.btnCamAtikBosalt);
            this.panel4.Location = new System.Drawing.Point(291, 370);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(305, 334);
            this.panel4.TabIndex = 5;
            // 
            // listCam
            // 
            this.listCam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.listCam.FormattingEnabled = true;
            this.listCam.ItemHeight = 16;
            this.listCam.Location = new System.Drawing.Point(13, 49);
            this.listCam.Margin = new System.Windows.Forms.Padding(4);
            this.listCam.Name = "listCam";
            this.listCam.Size = new System.Drawing.Size(268, 196);
            this.listCam.TabIndex = 7;
            // 
            // btnCamAtikEkle
            // 
            this.btnCamAtikEkle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnCamAtikEkle.Enabled = false;
            this.btnCamAtikEkle.FlatAppearance.BorderSize = 0;
            this.btnCamAtikEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnCamAtikEkle.Location = new System.Drawing.Point(13, 11);
            this.btnCamAtikEkle.Margin = new System.Windows.Forms.Padding(4);
            this.btnCamAtikEkle.Name = "btnCamAtikEkle";
            this.btnCamAtikEkle.Size = new System.Drawing.Size(269, 31);
            this.btnCamAtikEkle.TabIndex = 5;
            this.btnCamAtikEkle.Text = "CAM";
            this.btnCamAtikEkle.UseVisualStyleBackColor = false;
            this.btnCamAtikEkle.Click += new System.EventHandler(this.btnCamAtikEkle_Click);
            // 
            // prgCamAtik
            // 
            this.prgCamAtik.Location = new System.Drawing.Point(17, 256);
            this.prgCamAtik.Margin = new System.Windows.Forms.Padding(4);
            this.prgCamAtik.Name = "prgCamAtik";
            this.prgCamAtik.Size = new System.Drawing.Size(265, 25);
            this.prgCamAtik.TabIndex = 6;
            // 
            // btnCamAtikBosalt
            // 
            this.btnCamAtikBosalt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(203)))), ((int)(((byte)(207)))));
            this.btnCamAtikBosalt.Enabled = false;
            this.btnCamAtikBosalt.FlatAppearance.BorderSize = 0;
            this.btnCamAtikBosalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.btnCamAtikBosalt.Location = new System.Drawing.Point(13, 288);
            this.btnCamAtikBosalt.Margin = new System.Windows.Forms.Padding(4);
            this.btnCamAtikBosalt.Name = "btnCamAtikBosalt";
            this.btnCamAtikBosalt.Size = new System.Drawing.Size(269, 37);
            this.btnCamAtikBosalt.TabIndex = 5;
            this.btnCamAtikBosalt.Text = "BOŞALT";
            this.btnCamAtikBosalt.UseVisualStyleBackColor = false;
            this.btnCamAtikBosalt.Click += new System.EventHandler(this.btnCamAtikBosalt_Click);
            // 
            // timerGameTime
            // 
            this.timerGameTime.Interval = 1000;
            this.timerGameTime.Tick += new System.EventHandler(this.timerOyunZamani_Tick);
            // 
            // atikToplamaOyunu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(939, 702);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimizeBox = false;
            this.Name = "atikToplamaOyunu";
            this.Text = "ATIK TOPLAMA";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAtikImage)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnYeniOyun;
        private System.Windows.Forms.ProgressBar prgKagitAtik;
        private System.Windows.Forms.Button btnKagitAtikBosalt;
        private System.Windows.Forms.ProgressBar prgMetalAtik;
        private System.Windows.Forms.Button btnMetalAtikBosalt;
        private System.Windows.Forms.ProgressBar prgOrganikAtik;
        private System.Windows.Forms.Button btnOrganikAtikBosalt;
        private System.Windows.Forms.ProgressBar prgCamAtik;
        private System.Windows.Forms.Button btnCamAtikBosalt;
        private System.Windows.Forms.ListBox listKagit;
        private System.Windows.Forms.Button btnkagitAtikEkle;
        private System.Windows.Forms.ListBox listMetal;
        private System.Windows.Forms.Button btnMetalAtikEkle;
        private System.Windows.Forms.ListBox listOrg;
        private System.Windows.Forms.Button button_OrganikAtikEkle;
        private System.Windows.Forms.ListBox listCam;
        private System.Windows.Forms.Button btnCamAtikEkle;
        private System.Windows.Forms.PictureBox picAtikImage;
        private System.Windows.Forms.Timer timerGameTime;
        private System.Windows.Forms.TextBox lblPuan;
        private System.Windows.Forms.TextBox label_OyunSuresi;
    }
}

