/****************************************************************************
**
**				OGRENCI ADI.......:OMER FARUK SUSUZ
**				OGRENCI NUMARASI.............:B181210379
**				DERS GRUBU�������:1-B
****************************************************************************/
#include "pch.h"
#include <iostream>
#include <ctime>
#include <stdlib.h> 
#include <iomanip>
using namespace std;
void matris_sekil(int matris[25][25], int boyut);
int basamak_bulma(int x);
int main()
{
	int boyut = 0;
	int islem;
	int satir = 0, sutun = 0;
	int i = 0, j = 0;
	int matris[25][25];
	int kesisim = 0;
	int swap_1 = 0, swap_2 = 0, swap_3 = 0, swap_4 = 0;
	int toplam_matris = 0;
	int  basamaks = 1;

	while (boyut < 5 || boyut>25)
	{
		cout << "Matris boyutu:";
		cin >> boyut;
		cout << endl;
	}
	srand(time(0));

	for (i = 0; i < boyut; i++)
	{
		for (j = 0; j < boyut; j++)
		{
			matris[i][j] = rand() % 9 + 1;
		}
	}
	matris_sekil(matris, boyut);

	cout << endl;
	cout << "1.Sutun satir degistir:" << endl;
	cout << "2.Tekleri basa al(Satir):" << endl;
	cout << "3.Ters cevir(Sutun):" << endl;
	cout << "4.Toplamlari yazdir:" << endl;

	cin >> islem;

	switch (islem)
	{
	case 1:
		satir = 30;
		while (satir > 25 || sutun > 25 || satir > boyut || sutun > boyut)
		{
			cout << "Satir sutun:";
			cin >> satir >> sutun;
			if (satir > 25 || sutun > 25 || satir > boyut || sutun > boyut)
			{
				cout << "Satir ve sutun matris boyutundan buyuk olamaz.";
				cout << endl;
				matris_sekil(matris, boyut);
				cout << "1.Sutun satir degistir:" << endl;
				cout << "2.Tekleri basa al(Satir):" << endl;
				cout << "3.Ters cevir(Sutun):" << endl;
				cout << "4.Toplamlari yazdir:" << endl;
				cin >> islem;
			}
		}
		kesisim = matris[satir - 1][sutun - 1] * 2;

		for (j = boyut - 1; j >= 0; j--)
		{
			swap_1 = matris[satir - 1][j];
			matris[satir - 1][j] = matris[j][sutun - 1];
			matris[j][sutun - 1] = swap_1;
		}
		matris[satir - 1][sutun - 1] = kesisim;

		matris_sekil(matris, boyut);


		break;
	case 2:
		satir = 30;
		while (satir > 25 || satir > boyut)
		{
			cout << "Satir:";
			cin >> satir;
			if (satir > 25 || satir > boyut)
			{
				cout << "Satir matris boyutundan buyuk olamaz.";
				cout << endl;
				matris_sekil(matris, boyut);
				cout << "1.Sutun satir degistir:" << endl;
				cout << "2.Tekleri basa al(Satir):" << endl;
				cout << "3.Ters cevir(Sutun):" << endl;
				cout << "4.Toplamlari yazdir:" << endl;
				cin >> islem;
			}

		}
		for (i = 0; i < boyut; i++)
		{
			for (j = 0; j < boyut - i - 1; j++)
			{
				if (matris[satir - 1][i] % 2 == 0)
				{
					swap_2 = matris[satir - 1][i];
					matris[satir - 1][i] = matris[satir - 1][boyut - 1 - j];
					matris[satir - 1][boyut - 1 - j] = swap_2;
				}
			}
		}
		matris_sekil(matris, boyut);
		break;

	case 3:
		sutun = 30;
		while (sutun > 25 || sutun > boyut)
		{
			cout << "Sutun:";
			cin >> sutun;
			if (sutun > 25 || sutun > boyut)
			{
				cout << "Sutun matris boyutundan buyuk olamaz.";
				cout << endl;
				matris_sekil(matris, boyut);
				cout << "1.Sutun satir degistir:" << endl;
				cout << "2.Tekleri basa al(Satir):" << endl;
				cout << "3.Ters cevir(Sutun):" << endl;
				cout << "4.Toplamlari yazdir:" << endl;
				cin >> islem;
			}
		}

		for (i = 0; i < boyut / 2; i++)
		{
			swap_3 = matris[i][sutun - 1];
			matris[i][sutun - 1] = matris[boyut - 1 - i][sutun - 1];
			matris[boyut - 1 - i][sutun - 1] = swap_3;
		}

		matris_sekil(matris, boyut);
		break;
	case 4:

		for (i = 0; i < boyut; i++)
		{
			for (j = 0; j < boyut; j++)
			{
				toplam_matris = toplam_matris + matris[i][j];
			}
		}
		i = 0;
		j = 0;
		swap_4 = toplam_matris;
		matris[i][j] = 0;
		for (i = 0; i < boyut; i++)
		{
			for (j = 0; j < boyut; j++)
			{

				toplam_matris = toplam_matris - matris[i][j];
				matris[i][j] = toplam_matris;
			}
		}

		i = 0; j = 0;
		toplam_matris = swap_4;

		matris[i][j] = toplam_matris;

		matris_sekil(matris, boyut);
		break;
	}

	cout << "_______________________________"<<endl;
	int qr;
	cin >> qr;
	return 0;
}
void matris_sekil(int matris[25][25], int boyut)
{
	int i = 0;
	int j = 0;
	cout << "        ";
	for (i = 1; i < boyut+1; i++)
		if (i<10)
			cout << i << "    ";
		else 
		cout << i<<"   ";
	cout << "\n";
	//----------------------------------
	cout << "        _";
	for (i = 1; i < boyut; i++)
		cout << "    _";
	cout << "\n";

	for (i = 0; i < boyut; i++)
	{
		//--------------------------------------sutun bosluk duzeltme
		if (i<=8)
			cout << i + 1 << "|  ";
		else
			cout << i+1 << "| ";
		//--------------------------------------sutun bosluk duzeltme
		for (j = 0; j < boyut; j++)
		{
			cout << setw(5- basamak_bulma(matris[i][j]));
			cout << "" << matris[i][j];
		}
		cout << endl;
	}
}
int basamak_bulma(int sayi)
{
	int sayac = 1;
	while (sayi >= 10)
	{
		sayi = sayi / 10;
		sayac++;
	}

	return sayac;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
