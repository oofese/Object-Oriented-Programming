/****************************************************************************
**				
**				OGRENCI ADI.......:OMER FARUK SUSUZ
**				OGRENCI NUMARASI.............:B181210379
**				DERS GRUBU:1-B
****************************************************************************/
//Kutuphaneler
#include <iostream>
#include <stdlib.h> 
#include <time.h>
#include <iomanip>
#include <windows.h>
#include <conio.h>
#include <fstream>
using namespace std;
int NumaraSayaci=100;
class Ogrenci
{
	private:
		string isim;
		string soyisim;
		int number;
	
	public:
		
	
		void isimata(string name)
		{	
			isim=name;
		}
		void soyisimata(string name)
		{	
			soyisim=name;
		}
		void numaraAta(int x)
		{
			number=x;
		}

		string isim_goster()
		{
			return isim+" "+soyisim;
		}
		int numara_goster()
		{
			return number;
		}
};

class DosyaYonetim
{
	public:
		fstream dosya;
		char text[50];
		string array[5000];
		int i,sayac;
		public:
//--------------------------------------------			
	string isimoku()
	{
	//	DosyaYonetim d1;
		
		dosya.open("isimler.txt",ios::out|ios::in|ios::app);
		i=0;
		sayac=0;
		srand(time(0));
		while(!dosya.eof())
		{
			dosya>>array[i];
		//	cout<<array[i];
			sayac++;
		//	cout<<endl;
			i++;
			
		}
	//	cout<<sayac;
	//	cout<<endl;
	//	cout<<array[rand()%sayac];
			
		dosya.close();	
		return array[rand()%sayac];
	}
//--------------------------------------------	
	string soyisimoku()
	{
		dosya.open("soyisimler.txt",ios::out|ios::in|ios::app);
		i=0;
		sayac=0;
		srand(time(0));
		while(!dosya.eof())
		{
			dosya>>array[i];
	//		cout<<array[i];
			sayac++;
	//		cout<<endl;
			i++;
			
		}
		dosya.close();	
		return array[rand()%sayac];	
	}
//------------------------------------------	
	void KayitOgrenci(Ogrenci ogr)
	{
		dosya.open("kayit.txt",ios::out|ios::in|ios::app);
		
		dosya<<ogr.isim_goster();
		
		dosya.close();	
	}
//-----------------------------------------	
	void KayitSinif()
	{
		
	}
	
};
class Sinif
{
	private:
		Ogrenci ogrenciler[100];
		int ogrenciSayisi;
	public:
		DosyaYonetim d1;
		string sinifIsmi[2];
		char sinifNumarasi;
		
		string SinifismiBulma()
		{
			srand(time(0));
			sinifNumarasi++;
			sinifIsmi[0]=sinifNumarasi;
			sinifIsmi[1]= 65 + rand() % 25;
			
			return 	sinifIsmi[0]+sinifIsmi[1];
		}
		void OgrenciEkle()
		{
			ogrenciler[ogrenciSayisi].isimata(d1.isimoku());
			ogrenciler[ogrenciSayisi].soyisimata(d1.soyisimoku());
			ogrenciler[ogrenciSayisi].numaraAta(NumaraSayaci);
			NumaraSayaci++;
			ogrenciSayisi++;	
		}
		void OgrenciSil(int numara)
		{
			for(int i=0;i<ogrenciSayisi-1;i++)
			{
				if(ogrenciler[i].numara_goster()==numara)
					ogrenciSayisi--;
				else
					continue;
			}			
		}
		Sinif()
		{
			ogrenciSayisi=0;
			sinifNumarasi=48;
		}
		void deneme(int x)
		{
			cout<<setw(15)<<ogrenciler[x].isim_goster()<<endl;
			cout<<setw(8)<<NumaraSayaci;	
		}

};
class Okul
{
	public:
	char solUstKose;
	char duz ;
	char sagUstKose ;
	char solAltKose ;
	char sagAltKose ;
	Sinif s1;
	
	public:
		void ustYazdir(int elemanSayisi)
		{
		 duz = 205;
		 solUstKose = 201;
		 sagUstKose = 187;
			
			cout << solUstKose;
			for (int i = 0; i < elemanSayisi; i++)
			{
				cout << duz;
			}
			cout << sagUstKose;
		}
		
		void altYazdir(int elemanSayisi)
		{
		 duz = 205;
		 solAltKose = 200;
		 sagAltKose = 188;
			cout << solAltKose;
			for (int i = 0; i < elemanSayisi; i++)
			{
				cout << duz;
			}
			cout << sagAltKose;
		}
		
		void sinif_Yazdir()
		{
			
		ustYazdir(17);
		cout<<endl;
		cout<<setw(10)<<s1.SinifismiBulma();
		cout<<endl;
		altYazdir(17);
		cout<<endl;
				
		}
		void ogrenci_Yazdir()
		{
		ustYazdir(12);
		cout<<endl;
		setw(5);
		s1.OgrenciEkle();	
		s1.deneme(0);
		cout<<endl;	
		altYazdir(12);
		cout<<endl;	
		}
	
};
class Program
{
	public:
	int secim;
	Okul o1;

	void calistir()
	{
		while(secim!=6)
	{
		
		cout<<"1-Ogrenci Ekle" <<endl<<"2-Sinif Ekle "<<endl<<"3-Ogrenci Degistir"<<endl<<"4-Ogrenci Sil"<<endl<< "5-Sinif Sil"<<endl<< "6-Cikis"<<endl;
		cin>>secim;
		switch(secim)
		{
			
			case 1:
				o1.ogrenci_Yazdir();
			break;	
			
			case 2:
				o1.sinif_Yazdir();
			break;
			
			case 3:
			break;
			
			case 4:
			break;
			
			case 5:
			break;
			
			case 6:
			break;
					
		}
	}
		
				
	}
	Program()
	{
		secim=0;
	}
	
};
int main()
{
	 
//	Ogrenci a1;	
//	DosyaYonetim d1;
	
//	cout<<d1.isimoku()<<endl;
//	cout<<d1.soyisimoku();
//	a1.isimata();
//	cout<<a1.isim<<a1.soyisim<<endl;
//	cout<<a1.isim_goster();
//	d1.KayitOgrenci(a1);
//Sinif s1;
//s1.OgrenciEkle();
/*d1.KayitOgrenci();
	o1.ustYazdir(10);	
	cout<<endl;
	s1.OgrenciEkle();
	s1.deneme(0);
//	cout<<endl;
	cout<<s1.SinifismiBulma();
	cout<<endl;
	o1.altYazdir(10);
	cout<<endl;

*/
//o1.yazdir();
Program p1;
p1.calistir();




	return 0;
}
