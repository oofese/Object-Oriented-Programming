/****************************************************************************
**				
**				��RENC� ADI...........................:�MER FARUK SUSUZ
**				��RENC� NUMARASI.............:B181210379
**				DERS GRUBU�������:1B
****************************************************************************/
#include <iostream>
#include <windows.h>

using namespace std;

int main(){
	
	int satir=1;
	int sutun=1;
	int i,j,k,n;

	while(2*satir!=sutun)
	//sat�r-sutun iliskisi while ile kontrol
	{
		cout<<"Satir....:";
		cin>>satir;
	
		while(15<satir || satir<5)
	//Satir sayisi-while ile kontrol
	{
			cout<<"Satir numarasi hatali tekrar deneyin....\n";	
			cout<<"Satir :";
			cin>>satir;
	}
	
	cout<<"Sutun....:";
	cin>>sutun;
		while(40<sutun || sutun<5)
		//sutun sayisi while ile kontrol
	{
			cout<<"Sutun numarasi hatali tekrar deneyin....\n";	
			
			cout<<"Sutun....:";
			
			cin>>sutun;
	}
		if(2*satir!=sutun)
		//eger satir s�t�n iliskisi olmam�ssa
		{
			cout<<"Sutun sayisi satir sayisinin 2 kati olmalidir.....Tekrar deneyin.....:\n";
		}
		
	}
	//yildiz islemleri icin iki degisken k ve ne olmak �zere
	k=sutun/2;
	n=k;
	n++;
	//ilk basta k ve n'yi seklin ortasindan baslattim birer birer artirarak asagi indim ve yildiz bastim.
		for(i=1;i<=satir;i++)
		{
			
			for(j=1;j<=sutun;j++)
			{
				//Veya islemi ile kontrol edip yildiz basma if icinde
				if(j==k|| j==n || i==1 ||i==satir ||j==1 || j==sutun)
				{
					cout<<"*";
				}
				else
				{
					cout<<" ";
			
				}
				
			}
			cout<<"\n";
			k--;
			n++;
			Sleep(100);//Windows.h kutuphanesinde tanimli sleep fonksiyonu
		}
	
cout<<"\n\n";
//Alttaki sekil icin
	k=sutun;
	n=0;
	n++;
	//Burda da bastan baslatarak birer birer artirdim ve ortaya geldim.
	for(i=1;i<=satir;i++)
		{
			
			for(j=1;j<=sutun;j++)
			{
				if(j==k|| j==n || i==1 || i==satir || j==1 || j==sutun)
				{
					cout<<"*";
				}
				else
				{
					cout<<" ";
			
				}
				
			}
			cout<<"\n";
			k--;
			n++;
			Sleep(100);
		}

	return 0;
}
