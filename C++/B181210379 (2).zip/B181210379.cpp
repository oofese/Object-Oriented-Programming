/****************************************************************************
**				
**				OGRENCI ADI.......:OMER FARUK SUSUZ
**				OGRENCI NUMARASI.............:B181210379
**				DERS GRUBU:1-B
****************************************************************************/
//Kutuphaneler
#include <iostream>
#include <stdlib.h> 
#include <time.h>
#include <iomanip>
#include <windows.h>
#include <conio.h>
#include <unistd.h>

struct Sahne{       //struct yap�lar�
	
	int genislik;
	int yukseklik;
	char karakter;
	
};
struct Lsekli{
		int x;
		int y;
		char karakter;
		int boyut;
	};

using namespace std;

//fonksiyonlar,ekstra cursor icin var invisible cursor
void sahneCiz(Sahne sahne);
struct Sahne sahneOlustur();
struct Lsekli lSekliOlustur();
void lSekliCiz(Lsekli sekil);
void koordinatAta(int x, int y);
void setcursor(bool visible, DWORD size);
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);

void setcursor();

int main()
{
    setcursor(0,0);
	struct Sahne s1=sahneOlustur();
	struct Lsekli l1=lSekliOlustur();
	while(true)
    {
        if (l1.y+l1.boyut==s1.yukseklik-1)
        {
            l1=lSekliOlustur();
        }
        
        sahneCiz(s1);
        lSekliCiz(l1);
        Sleep(100);
        l1.y++;
        system("cls");
    }
	    cin.get();
	
return 0;
}
struct Sahne sahneOlustur() //sahne olustur randla deger atama
{
	struct Sahne sahne;
	int sekil[]={ '*','#','$','+','@' };
	srand(time(0));
	int rast;
	do{
		rast=rand()%6;
	}while (rast<3);
	rast*=10;
	
	sahne.genislik=rast;
	do{
		rast=rand()%31;
	}while (rast<20);

	sahne.yukseklik=rast;
	sahne.karakter=sekil[rand()%5];
	
	return sahne;	
}

void sahneCiz(Sahne sahne){  //sahne cizme for islemleri
	int i,j;
	 
	for (int i = 1; i <= sahne.genislik; i++)
		cout<<sahne.karakter;
        cout<<endl;
//--------------------------------------------------------
	for(i=2;i<sahne.yukseklik;i++)
	{
		cout<<sahne.karakter;
		for (int i = 2; i <sahne.genislik ; i++)
		{
			cout<<" ";
		}
		cout<<sahne.karakter<<endl;
	}
//--------------------------------------------------------
	for (int i = 0; i < sahne.genislik; i++)
	cout<<sahne.karakter;
}
struct Lsekli lSekliOlustur() //L sekil olustur  randla atama 
{

    struct Lsekli sekil;
    int rast;
    int eleman[] = {'*', '#', '$', '+', '@'};
    sekil.y = 3;
    srand(time(0));
    //--------------------------
    do
    {
        rast = rand() % 26;
    } while (rast < 5);

    sekil.x = rast;
    //--------------------------
    do
    {
        rast = rand() % 9;
    } while (rast <= 2 || rast % 2 == 1);

    sekil.boyut = rast;
    //--------------------------
    sekil.karakter = eleman[rand() % 5];
    return sekil;
}
void lSekliCiz(Lsekli sekil)     //L sekli for islemleri
{
    int i, j;
	int apsis,ordinat;
	apsis=sekil.x;
	ordinat=sekil.y;

    for (i = 0; i < sekil.boyut + 1; i++)
    {
	    koordinatAta(apsis,ordinat);
        if (i == 0)
        {
            for (j = 0; j < sekil.boyut / 2; j++)
            {
                cout << sekil.karakter;
            }
            cout << endl;
        }
        //-----------------------------
        else if (i < sekil.boyut / 2)
        {

            for (j = 0; j < sekil.boyut / 2; j++)
            {
                if (j == 0 || j == sekil.boyut / 2 - 1)
                    cout << sekil.karakter;
                else
                {
                    cout << " ";
                }
            }
            ordinat--;
            cout << endl;
        }
        //-----------------------------
        else if (i == sekil.boyut / 2 + 1)
        {
            for (j = 0; j <= sekil.boyut; j++)
            {
                if (j == 0)
                    cout << sekil.karakter;
                else if (j >= 1 && j <= sekil.boyut / 2 - 2)
                    cout << " ";
                else if (j > sekil.boyut / 2 - 1)
                    cout << sekil.karakter;
            }
            cout << endl;
        }
        //-----------------------------
        else if (i > sekil.boyut / 2 && i <= sekil.boyut)
        {
            for (j = 0; j < sekil.boyut; j++)
            {
                if (j == 0 || j == sekil.boyut - 1)
                    cout << sekil.karakter;
                else
                {
                    cout << " ";
                }
            }
            cout << endl;
        }
        //------------------------------
		     
        ordinat++;
    }
    koordinatAta(apsis,ordinat);
        for (j = 0; j < sekil.boyut; j++)
                cout << sekil.karakter;
}
void koordinatAta(int x, int y)   //Cursor imlecini belirlenen koordinata goturme
{
	COORD coord;
	coord.X = x;
	coord.Y = y;

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void setcursor(bool visible, DWORD size) //Cursor icin kod-invisible
{
	if(size == 0)
	{
		size = 20;	
	}
	CONSOLE_CURSOR_INFO lpCursor;	
	lpCursor.bVisible = visible;
	lpCursor.dwSize = size;
	SetConsoleCursorInfo(console,&lpCursor);
}

